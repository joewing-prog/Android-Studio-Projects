package com.example.newsgateway;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import java.util.ArrayList;


public class SourceRunnable implements Runnable{

    private final MainActivity mainActivity;

    //String sourceurl = "https://newsapi.org/v2/sources?apiKey=c4f8aca4374a46c991beeeb70199a00a"; //ALL SOURCES
    String sourceurl = "https://newsapi.org/v2/sources?apiKey=9a977ad392964b188a2f72c6cedf2c7a";

    private static final String TAG = "SourceRunnable";

    SourceRunnable(MainActivity mainActivity){
        this.mainActivity = mainActivity;

    }

    @Override
    public void run() {
        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(sourceurl);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.addRequestProperty("User-Agent", "");
            conn.connect();

            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                Log.d(TAG, "run: HTTP ResponseCode NOT OK: " + conn.getResponseCode());
                handleResults(null);
                return;
            }

            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e) {
            Log.e(TAG, "run: ", e);
            handleResults(null);
            return;
        }
        handleResults(sb.toString());
    }

    private void handleResults(String s) {
        if (s == null) {
            Log.d(TAG, "handleResults: Failure in data download");
            mainActivity.runOnUiThread(mainActivity::downloadFailed);
            return;
        }

        final ArrayList<NewsSource> newsList = parseJSON(s);
        if (newsList == null) {
            mainActivity.runOnUiThread(mainActivity::downloadFailed);
            return;
        }

        mainActivity.runOnUiThread(
                () -> mainActivity.updateDataAll(newsList));
    }

    private ArrayList<NewsSource> parseJSON(String s) {

        ArrayList<NewsSource> newsList = new ArrayList<>();

        try {

            //pull all source names from News API
            JSONObject jObjMain = new JSONObject(s);
            JSONArray sources = jObjMain.getJSONArray("sources");

            for (int i=0; i<sources.length(); i++) {
                JSONObject source = (JSONObject) sources.get(i);
                String source_id = source.getString("id");
                String source_name = source.getString("name");

                String topic =  source.getString("category");
                String lang = source.getString("language");
                String country = source.getString("country");

                newsList.add(new NewsSource(source_id, source_name, topic, lang, country));
            }

            return newsList;
        } catch (Exception e) {
            Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
