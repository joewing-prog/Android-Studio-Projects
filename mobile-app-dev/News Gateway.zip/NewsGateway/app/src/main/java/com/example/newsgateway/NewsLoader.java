package com.example.newsgateway;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class NewsLoader implements Runnable{

    private final String TAG = "NewsLoader";
    private final MainActivity mainActivity;
    private final String source_id;

    //sample URL for ABC News: https://newsapi.org/v2/top-headlines?sources=abc-news&apiKey=c4f8aca4374a46c991beeeb70199a00a

    private static final String sourceURL = "https://newsapi.org/v2/top-headlines";
    //private static final String APIKey = "c4f8aca4374a46c991beeeb70199a00a";
    private static final String APIKey = "9a977ad392964b188a2f72c6cedf2c7a";


    public NewsLoader(MainActivity mainActivity, String source_id) {
        this.mainActivity = mainActivity;
        this.source_id = source_id;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void run() {
        Uri.Builder buildURL = Uri.parse(sourceURL).buildUpon();
        buildURL.appendQueryParameter("sources",source_id);
        buildURL.appendQueryParameter("apiKey",APIKey);
        String urlToUse = buildURL.build().toString();
        Log.d(TAG, "doInBackground: " + urlToUse);

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlToUse);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.addRequestProperty("User-Agent", "");
            conn.connect();

            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                Log.d(TAG, "run: HTTP ResponseCode NOT OK: " + conn.getResponseCode());
                handleResults(null);
                return;
            }

            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e) {
            Log.e(TAG, "run: ", e);
            handleResults(null);
            return;
        }
        handleResults(sb.toString());
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void handleResults(String s) {
        if (s == null) {
        Log.d(TAG, "handleResults: Failure in data download");
        mainActivity.runOnUiThread(mainActivity::downloadFailed);
        return;
    }

        final ArrayList<NewsEntry> newsList = parseJSON(s);
        if (newsList == null) {
            mainActivity.runOnUiThread(mainActivity::downloadFailed);
            return;
        }

        mainActivity.runOnUiThread(
                () -> mainActivity.updateDataEntry(newsList));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private ArrayList<NewsEntry> parseJSON(String s) {
        ArrayList<NewsEntry> newsList = new ArrayList<>();

        try {

            //pull all source info from News API top 10 articles
            JSONObject jObjMain = new JSONObject(s);
            String count = jObjMain.getString("totalResults");

            JSONArray articles = jObjMain.getJSONArray("articles");
            for (int i=0;i<articles.length();i++) {
                if (i>10) {
                    return newsList;
                }
                JSONObject article = (JSONObject) articles.get(i);
                
                String headline = article.getString("title");
                if (headline.equals("null")) {
                    headline="No headline";
                }
                
                String publishedAt = article.getString("publishedAt");
                int year = Integer.parseInt(publishedAt.substring(0, 4));
                int month = Integer.parseInt(publishedAt.substring(5, 7)) - 1;
                int date = Integer.parseInt(publishedAt.substring(8, 10));
                int hour = Integer.parseInt(publishedAt.substring(11, 13));
                int minute = Integer.parseInt(publishedAt.substring(14, 16));
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, date, hour, minute);
                Date dateObject = calendar.getTime();
                @SuppressLint("SimpleDateFormat") String newDate = (String) new SimpleDateFormat("MMM dd, yyyy HH:mm").format(dateObject);

                String author = article.getString("author");
                if (author.equals("null")) {
                    author="No author";
                }

                String img_url = article.getString("urlToImage");

                String description = article.getString("description");
                if (description.equals("")||description.equals("null")) {
                    description="No description";
                }

                String url = article.getString("url");
                url.replaceAll("/","");

                newsList.add(new NewsEntry(headline, newDate, author, img_url, description, count, url));
            }

            return newsList;
        } catch (Exception e) {
            Log.d(TAG, "parseJSON: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

//    @RequiresApi(api = Build.VERSION_CODES.O)
//    private String newFormatDateTime(String tzDateTime){
//        try {
//            DateTimeFormatter parseFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSSSSSS]XXXXX");
//            LocalDateTime date = LocalDateTime.parse(tzDateTime, parseFormatter).truncatedTo(ChronoUnit.SECONDS);
//            Log.d(TAG,"newFormatDateTime: Parsed publish date is " + date);
//            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MMM d, yyyy HH:mm");
//            String ret = date.format(dateTimeFormatter);
//            return ret;
//        } catch (DateTimeParseException e) {
//            Log.d(TAG, String.format("newFormatDateTime: %s is not parsable%n, ", tzDateTime));
//
//            throw e;
//        }
//    }

    //date formats:
    //yyyy-MM-dd'T'HH:mm:ss'Z
    //yyyy-MM-dd'T'HH:mm:ss[.SSSS]XXXXX
    //yyyy-MM-dd'T'HH:mm:ss.SSS'Z
}

