package com.example.newsgateway;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Locale;

public class NewsAdapter extends RecyclerView.Adapter<NewsViewHolder>{

    private final MainActivity mainActivity;
    private final ArrayList<NewsEntry> newsList;
    private final String TAG = "NewsAdapter";

    private Picasso picasso;

    public NewsAdapter(MainActivity mainActivity, ArrayList<NewsEntry> newsList) {
        this.mainActivity = mainActivity;
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NewsViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(R.layout.news_entry, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsEntry newsentry = newsList.get(position);

        holder.headline.setText(newsentry.getHeadline());

        holder.headline.setOnClickListener(v -> onClick(position));

        holder.date.setText(newsentry.getDate());
        holder.author.setText(newsentry.getAuthor());

        long millisS = System.currentTimeMillis();

        picasso = Picasso.get();

        if (newsList.get(position).getImg_url().equals("")) {
            picasso.load(R.drawable.brokenimage);
        }
        else {
            picasso.load(newsList.get(position).getImg_url())
                    .error(R.drawable.noimage)
                    .placeholder(R.drawable.loading)
                    .into(holder.imageView, new Callback() {
                                @Override
                                public void onSuccess() {
                                    long millisE = System.currentTimeMillis();
                                    Log.d(TAG, "loadRemoteImage: Duration: " +
                                            (millisE - millisS) + " ms");
                                }

                                @Override
                                public void onError(Exception e) {
                                }
                            }
                    );
        }

        holder.imageView.setOnClickListener(v -> onClick(position));


        holder.description.setText(newsentry.getDescription());
        holder.description.setOnClickListener(v -> onClick(position));

        holder.count.setText(String.format(
                Locale.getDefault(),"%d of %d", (position+1), newsList.size()));
    }

    public void onClick(int position) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(newsList.get(position).getUrl()));
            mainActivity.startActivity(intent);
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }
}
