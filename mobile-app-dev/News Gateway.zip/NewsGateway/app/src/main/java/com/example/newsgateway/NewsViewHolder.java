package com.example.newsgateway;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NewsViewHolder extends RecyclerView.ViewHolder {

    TextView headline;
    TextView date;
    TextView author;
    TextView description;
    TextView count;
    ImageView imageView;

    public NewsViewHolder(@NonNull View itemView) {
        super(itemView);
        headline = itemView.findViewById(R.id.headline);
        date = itemView.findViewById(R.id.date);
        author = itemView.findViewById(R.id.author);
        description = itemView.findViewById(R.id.description);
        count = itemView.findViewById(R.id.count);
        imageView = itemView.findViewById(R.id.imageView);
    }
}