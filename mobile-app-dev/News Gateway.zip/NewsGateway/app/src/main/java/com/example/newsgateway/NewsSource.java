package com.example.newsgateway;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class NewsSource implements Serializable {

    private final String id;
    private final String name;

    private final String topic;
    private final String lang;
    private final String country;

    public NewsSource(String id, String name, String topic, String lang, String country){
        this.id = id;
        this.name = name;
        this.topic = topic;
        this.lang = lang;
        this.country = country;

    }

    String getId() { return id; }
    String getName() { return name; }
    String getTopic() { return topic; }
    String getLang() { return lang; }
    String getCountry() { return country; }

    @NonNull
    public String toString() {
        return name;
    }

}
