package com.example.newsgateway;

import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.ArrayAdapter;

import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Menu opt_menu;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;

    private final HashMap<String, HashSet<String>> topicToSource = new HashMap<>();
    private final HashMap<String, HashSet<String>> langToSource = new HashMap<>();
    private final HashMap<String, HashSet<String>> countryToSource = new HashMap<>();
    private final HashMap<String, HashSet<String>> nameToSource = new HashMap<>();

    private final ArrayList<NewsEntry> currentNewsList = new ArrayList<>();

    Hashtable<String, String> query = new Hashtable<>();

    private NewsAdapter newsAdapter;
    private ArrayAdapter<String> arrayAdapter;

    private final ArrayList<NewsSource> newsSourceList = new ArrayList<>();
    private ArrayList<String> newsToDisplay = new ArrayList<>();

    private ViewPager2 viewPager;

    boolean topics = false;
    boolean languages = false;
    boolean countries = false;

    //String url = https://newsapi.org/v2/sources?apiKey=c4f8aca4374a46c991beeeb70199a00a //ALL SOURCES

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDrawerLayout = findViewById(R.id.drawer_layout);
        mDrawerList = findViewById(R.id.drawer_list);

        newsAdapter = new NewsAdapter(this, currentNewsList);
        viewPager = findViewById(R.id.viewpager);
        viewPager.setAdapter(newsAdapter);
        viewPager.setOrientation(viewPager.ORIENTATION_HORIZONTAL);

        // Set up the drawer item click callback method
        mDrawerList.setOnItemClickListener(
                (parent, view, position, id) -> {
                    selectItem(position);
                    mDrawerLayout.closeDrawer(mDrawerList);
                }
        );

        // Create the drawer toggle
        mDrawerToggle = new ActionBarDrawerToggle(this,
                mDrawerLayout,
                R.string.drawer_open,
                R.string.drawer_close);

        doDownloadAll();
    }

    private void selectItem(int position) { //for DrawerLayout
        viewPager.setBackground(null);
        String selectedSource = newsToDisplay.get(position);
        Log.d(TAG, "selectItem: " + selectedSource);
        String id = nameToSource.get(selectedSource).toString();
        Log.d(TAG, "selectItem: " + id);
        String source_id = id.substring(1,id.length()-1);
        Log.d(TAG, "selectItem: " + source_id);

        setTitle(selectedSource);

        new Thread(new NewsLoader(this, source_id)).start();

        viewPager.setCurrentItem(0);

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggle
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) { //for menuItems

        // Important!
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            Log.d(TAG, "onOptionsItemSelected: mDrawerToggle " + item);
            return true;
        }

        //appending query into a dictionary
        if (item.getTitle().equals("Topics")) {
            topics = true;
            return super.onOptionsItemSelected(item);
        }
        if (item.getTitle().equals("Language")) {
            languages = true;
            return super.onOptionsItemSelected(item);
        }
        if (item.getTitle().equals("Country")) {
            countries = true;
            return super.onOptionsItemSelected(item);
        }

        if (topics) {
            query.put("Topics",item.getTitle().toString());
            topics = false;
        }
        if (languages) {
            query.put("Languages",item.getTitle().toString());
            languages = false;
        }
        if (countries) {
            query.put("Countries",item.getTitle().toString());
            countries = false;
        }

        //begin sorting
        newsToDisplay.clear();

        if (query.containsKey("Topics")) {
            Set<String> topiclst;
            if (query.get("Topics").equals("all")) {
                topiclst = nameToSource.keySet();
                query.remove("Topics");
            }
            else {
                topiclst = topicToSource.get(query.get("Topics"));
            }
            newsToDisplay.addAll(topiclst);
            Collections.sort(newsToDisplay);

            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");
        }

        if (query.containsKey("Languages")) {
            String language = query.get("Languages");
            Set<String> langslst;
            if (query.get("Languages").equals("all")) {
                langslst = nameToSource.keySet();
                query.remove("Languages");
            }
            else {
                langslst = langToSource.get(langNameToCode(language));
            }

            if (langslst != null) {
                newsToDisplay.addAll(langslst);
            }
            Collections.sort(newsToDisplay);
            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");
        }

        if (query.containsKey("Countries")) {
            String country = query.get("Countries");
            Set<String> countrieslst;
            if (query.get("Countries").equals("all")) {
                countrieslst = nameToSource.keySet();
                query.remove("Countries");
            }
            else {
               countrieslst = countryToSource.get(countryNameToCode(country));
            }

            if (countrieslst != null) {
                newsToDisplay.addAll(countrieslst);
            }
            Collections.sort(newsToDisplay);
            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");
        }

        if (query.containsKey("Topics")&&query.containsKey("Languages")) {
            HashSet<String> topiclst = topicToSource.get(query.get("Topics"));
            HashSet<String> langslst = langToSource.get(langNameToCode(query.get("Languages")));

            topiclst.retainAll(langslst);
            newsToDisplay.clear();
            newsToDisplay.addAll(topiclst);
            Collections.sort(newsToDisplay);
            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");

        }
        if (query.containsKey("Topics")&&query.containsKey("Countries")) {
            HashSet<String> topiclst = topicToSource.get(query.get("Topics"));
            HashSet<String> countrieslst = countryToSource.get(countryNameToCode(query.get("Countries")));

            topiclst.retainAll(countrieslst);
            newsToDisplay.clear();
            newsToDisplay.addAll(topiclst);
            Collections.sort(newsToDisplay);
            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");
        }

        if (query.containsKey("Languages")&&query.containsKey("Countries")) {
            HashSet<String> langslst = langToSource.get(langNameToCode(query.get("Languages")));
            HashSet<String> countrieslst = countryToSource.get(countryNameToCode(query.get("Countries")));

            langslst.retainAll(countrieslst);
            newsToDisplay.clear();
            newsToDisplay.addAll(langslst);
            Collections.sort(newsToDisplay);
            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");
        }

        if (query.containsKey("Topics")&&query.containsKey("Languages")&&query.containsKey("Countries")) {
            HashSet<String> topiclst = topicToSource.get(query.get("Topics"));
            HashSet<String> langslst = langToSource.get(langNameToCode(query.get("Languages")));
            HashSet<String> countrieslst = countryToSource.get(countryNameToCode(query.get("Countries")));

            topiclst.retainAll(langslst);
            topiclst.retainAll(countrieslst);
            newsToDisplay.clear();
            newsToDisplay.addAll(topiclst);
            Collections.sort(newsToDisplay);
            arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
            mDrawerList.setAdapter(arrayAdapter);
            setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");
        }

        if (newsToDisplay.size() == 0) {
            // Simple dialog - no buttons.
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("No sources with the specified criteria exist");
            builder.setTitle("Alert");

            AlertDialog dialog = builder.create();
            dialog.show();
        }

        return super.onOptionsItemSelected(item);

    }

    private String langNameToCode(String language) {
        String json_string = readRawResource(R.raw.language_codes); //READ COUNTRY_CODES JSON FILE

        //COMPARE LANG CODE IN LANGUAGE CODES FILE
        try {
            JSONObject jObjMain = new JSONObject(json_string);
            JSONArray langs = (JSONArray) jObjMain.get("languages");

            for (int i = 0; i < langs.length(); i++) {
                JSONObject langComp = (JSONObject) langs.get(i);

                if (language.equals(langComp.getString("name"))) {
                    language = langComp.getString("code").toLowerCase();
                }

            }

        } catch (Exception e) {
            Log.d(TAG, "displayCountryName: " + e.getMessage());
            e.printStackTrace();
        }
        return language;
    }

    private String countryNameToCode(String country) {
        String json_string = readRawResource(R.raw.country_codes); //READ COUNTRY_CODES JSON FILE

        //COMPARE LANG CODE IN LANGUAGE CODES FILE
        try {
            JSONObject jObjMain = new JSONObject(json_string);
            JSONArray countries = (JSONArray) jObjMain.get("countries");

            for (int i = 0; i < countries.length(); i++) {
                JSONObject CountryComp = (JSONObject) countries.get(i);

                if (country.equals(CountryComp.getString("name"))) {
                    country = CountryComp.getString("code").toLowerCase();
                }

            }

        } catch (Exception e) {
            Log.d(TAG, "displayCountryName: " + e.getMessage());
            e.printStackTrace();
        }
        return country;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        opt_menu = menu;
        return true;
    }


    private void doDownloadAll() {
        SourceRunnable sourceLoaderRunnable = new SourceRunnable(this);
        new Thread(sourceLoaderRunnable).start();
    }

    public void downloadFailed() {
        Log.d(TAG, "downloadFailed: ");
    }

    public void updateDataAll(ArrayList<NewsSource> nList) {

        for (NewsSource newssource : nList) {
            String source_id = newssource.getId();
            String name = newssource.getName();
            String topic = newssource.getTopic();
            String lang = newssource.getLang();
            String country = newssource.getCountry();

            if (!topicToSource.containsKey(topic)) {
                topicToSource.put(topic, new HashSet<>());
            }
            Objects.requireNonNull(topicToSource.get(topic)).add(name);

            if (!langToSource.containsKey(lang)) {
                langToSource.put(lang, new HashSet<>());
            }
            Objects.requireNonNull(langToSource.get(lang)).add(name);

            if (!countryToSource.containsKey(country)) {
                countryToSource.put(country, new HashSet<>());
            }
            Objects.requireNonNull(countryToSource.get(country)).add(name);

            if (!nameToSource.containsKey(name)) {
                nameToSource.put(name, new HashSet<>());
            }
            Objects.requireNonNull(nameToSource.get(name)).add(source_id);

        }

        /////ADDING SOURCES TO DRAWER/////
        newsSourceList.clear();
        newsSourceList.addAll(nList);

        newsToDisplay = new ArrayList<>(nameToSource.keySet());
        Collections.sort(newsToDisplay);

        arrayAdapter = new ArrayAdapter<>(this, R.layout.drawer_item, newsToDisplay);
        mDrawerList.setAdapter(arrayAdapter);
        setTitle("News Gateway " + "(" + newsToDisplay.size() + ")");

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }


        //topics submenu
        ArrayList<String> tempListTopics = new ArrayList<>(topicToSource.keySet());

        SubMenu topics_subMenu = opt_menu.addSubMenu("Topics");
        topics_subMenu.add(0,0,0,"all");

       // Collections.sort(tempListTopics);

        for (String s : tempListTopics)
            topics_subMenu.add(s);


        //langs submenu
        ArrayList<String> tempListLangs = new ArrayList<>(langToSource.keySet());
        //read from local json file to convert lang code to lang name
        String json_string = readRawResource(R.raw.language_codes); //READ COUNTRY_CODES JSON FILE
        Log.d(TAG, "displayLangName: " + json_string);

        List<String> langsToDisplay = new ArrayList<>();

        //COMPARE COUNTRY CODES TO COUNTRIES IN COUNTRY_CODES JSON FILE
        try {
            JSONObject jObjMain = new JSONObject(json_string);
            JSONArray langs = (JSONArray) jObjMain.get("languages");

            for (int i = 0; i < langs.length(); i++) {
                JSONObject language = (JSONObject) langs.get(i);

                for (int j = 0; j < tempListLangs.size(); j++) { //comparison
                    if (tempListLangs.get(j).equals(language.getString("code").toLowerCase())) {
                        String languagename = language.getString("name");
                        langsToDisplay.add(languagename);
                    }
                }

            }

        } catch (Exception e) {
            Log.d(TAG, "displayCountryName: " + e.getMessage());
            e.printStackTrace();
        }

        SubMenu lang_subMenu = opt_menu.addSubMenu("Language");
        lang_subMenu.add(0,0,0,"all");

        for (String s : langsToDisplay)
            lang_subMenu.add(s);

        //countries submenu
        ArrayList<String> tempListCountries = new ArrayList<>(countryToSource.keySet());
        //read from local json file to convert country code to country name
        json_string = readRawResource(R.raw.country_codes); //READ COUNTRY_CODES JSON FILE
        Log.d(TAG, "displayCountryName: " + json_string);

        List<String> countriesToDisplay = new ArrayList<>();

        //COMPARE COUNTRY CODES TO COUNTRIES IN COUNTRY_CODES JSON FILE
        try {
            JSONObject jObjMain = new JSONObject(json_string);
            JSONArray countries = (JSONArray) jObjMain.get("countries");

            for (int i = 0; i < countries.length(); i++) {
                JSONObject country = (JSONObject) countries.get(i);

                for (int j = 0; j < tempListCountries.size(); j++) { //comparison
                    if (tempListCountries.get(j).equals(country.getString("code").toLowerCase())) {
                        String countryname = country.getString("name");
                        countriesToDisplay.add(countryname);
                    }
                }

            }

        } catch (Exception e) {
            Log.d(TAG, "displayCountryName: " + e.getMessage());
            e.printStackTrace();
        }

        SubMenu country_subMenu = opt_menu.addSubMenu("Country");
        country_subMenu.add(0,0,0,"all");

        for (String s : countriesToDisplay)
            country_subMenu.add(s);
    }

    //READ LOCAL JSON FILES
    public String readRawResource(@RawRes int res) {
        return readStream(this.getResources().openRawResource(res));
    }

    private String readStream(InputStream is) {
        Scanner s = new Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    public void updateDataEntry(ArrayList<NewsEntry> newsList) {
        currentNewsList.clear();
        if (newsList == null) {
            Toast.makeText(this, "Data loader failed", Toast.LENGTH_LONG).show();
        } else {
            this.currentNewsList.addAll(newsList);
            //newsAdapter.notifyItemRangeChanged(0, newsList.size());
            newsAdapter.notifyDataSetChanged();
        }

    }

}