package com.example.newsgateway;

public class NewsEntry {

    private final String headline;
    private final String date;
    private final String author;
    private final String img_url;
    private final String description;
    private final String count;
    private final String url;

    public NewsEntry(String headline, String date, String author, String img_url, String description, String count, String url) {
        this.headline = headline;
        this.date = date;
        this.author = author;
        this.img_url = img_url;
        this.description = description;
        this.count = count;
        this.url = url;
    }

    public String getHeadline() { return headline; }
    public String getDate() { return date; }
    public String getAuthor() { return author; }
    public String getImg_url() { return img_url; }
    public String getDescription() { return description; }
    public String getCount() { return count; }
    public String getUrl() { return url; }

}
