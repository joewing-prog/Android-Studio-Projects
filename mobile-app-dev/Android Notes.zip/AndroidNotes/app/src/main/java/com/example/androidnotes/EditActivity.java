package com.example.androidnotes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;

public class EditActivity extends AppCompatActivity {

    private EditText editTitle;
    private EditText editText;
    int position;
    String title;
    String text;

    private static final String TAG = "EditActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editTitle = findViewById(R.id.editTitlenew);
        editText = findViewById(R.id.editTextnew);

////////////////////////////////////////////////////////////////////////////////////////////////////
        Intent intent = getIntent();
        if (intent.hasExtra(Intent.EXTRA_TEXT)) { } //checks for text. if EXTRA_TEXT, then do not do editExistingNote (trying to determine the difference between making a new note and updating an existing one)
        else { editExistingNote(); }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.ea_opt_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void editExistingNote() {
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        title = extras.getString("notesTitle");
        Log.d(TAG, "onCreate: " + title);

        text = extras.getString("notesText");
        Log.d(TAG, "onCreate: " + text);

        position = extras.getInt("position");
        Log.d(TAG, "onCreate: " + position);

        editTitle.setText(title);
        editText.setText(text);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) { //EDITS MENU ITEMS
        if (item.getItemId() == R.id.save) {
            //CODE TO SAVE THIS NOTE
            if (editTitle.getText().toString().equals("")) { //if no title do NOT save
                Toast.makeText(this, "Can not save note without a title", Toast.LENGTH_SHORT).show();
                return super.onOptionsItemSelected(item);
            }
            else {
                saveNote();
            }
            return true;

        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void saveNote() { //sends over data from EditActivity to MainActivity
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        Date date = new Date();

        Intent data = new Intent();

        Log.d(TAG, "onOptionsItemSelected: Saved Title: " + editTitle.getText().toString());
        Log.d(TAG, "onOptionsItemSelected: Saved Text: " + editText.getText().toString());

        data.putExtra("notesTitle", editTitle.getText().toString());
        data.putExtra("notesText", editText.getText().toString());
        data.putExtra("lastSaveDate", dateFormat.format(date));
        data.putExtra("position", position);
        setResult(RESULT_OK, data);

        finish();
    }

    @Override
    public void onBackPressed() {
        // Pressing the back arrow closes the current activity, returning us to the original activity

        if ((title.equals(editTitle.getText().toString()) && (text.equals(editText.getText().toString())))) { //if title and text are equivalent, do not show dialog box
            super.onBackPressed();
        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("OK", (dialog, id) -> {

                if (!editTitle.getText().toString().equals("")) { //if editTitle is NOT empty
                    saveNote();
                }
                super.onBackPressed();
            } );

            builder.setNegativeButton("CANCEL", (dialog, id) -> { } ); //stay on EditActivity

            builder.setMessage("Text without any title will be lost forever.");
            builder.setTitle("Save note?");

            AlertDialog dialog = builder.create();
            dialog.setCancelable(false);
            dialog.show();
        }

    }



}