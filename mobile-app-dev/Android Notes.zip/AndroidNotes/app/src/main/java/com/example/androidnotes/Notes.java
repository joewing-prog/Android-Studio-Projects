package com.example.androidnotes;

import android.util.JsonWriter;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;

public class Notes implements Serializable {

    String title;
    String text;
    String last_save_date;

    public Notes(String title, String text, String last_save_date) {
        this.title = title;
        this.text = text;
        this.last_save_date = last_save_date;
    }

    void setTitle(String title) {
        this.title = title;
    }
    void setText(String text) {
        this.text = text;
    }
    void setLast_save_date(String last_save_date) {
        this.last_save_date = last_save_date;
    }

    String getTitle() { return title; }
    String getText() { return text; }
    String getLast_save_date() { return last_save_date; }

    @NonNull
    public String toString() {

        try {
            StringWriter sw = new StringWriter();
            JsonWriter jsonWriter = new JsonWriter(sw);
            jsonWriter.setIndent("  ");
            jsonWriter.beginObject();
            jsonWriter.name("title").value(getTitle());
            jsonWriter.name("text").value(getText());
            jsonWriter.name("last_save_date").value(getLast_save_date());
            jsonWriter.endObject();
            jsonWriter.close();
            return sw.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "";
    }

}