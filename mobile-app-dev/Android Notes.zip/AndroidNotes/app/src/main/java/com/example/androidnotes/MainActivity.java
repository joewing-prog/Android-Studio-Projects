package com.example.androidnotes;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener {

    private static final String TAG = "MainActivity";

    private final ArrayList<Notes> notesList = new ArrayList<>();
    private RecyclerView recyclerView;
    private NoteAdapter nAdapter;

    public boolean existing_note = false;

    private ActivityResultLauncher<Intent> activityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), this::handleResult);

        recyclerView = findViewById(R.id.recycler);

        nAdapter = new NoteAdapter(notesList,this);
        recyclerView.setAdapter(nAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.opt_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        notesList.clear();
        notesList.addAll(loadFile());
        super.onResume();
    }

    @Override
    protected void onPause() {
        notesList.clear();
        notesList.addAll(loadFile());
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        notesList.clear();
        notesList.addAll(loadFile());

        if (notesList.size()==0) {
            setTitle("Android Notes ");
        }
        else {
            setTitle("Android Notes " + "(" + String.valueOf(notesList.size()) + ")");
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) { //CREATE NEW NOTE AND ABOUT INFORMATION

        if (item.getItemId() == R.id.addNote) { //ADD NEW NOTE
       //     Toast.makeText(this, "Create new note", Toast.LENGTH_SHORT).show();
            existing_note = false;
            Intent intent = new Intent(this, EditActivity.class);
            intent.putExtra(Intent.EXTRA_TEXT,"new note");
            activityResultLauncher.launch(intent);

            return true;
        } else if (item.getItemId() == R.id.info) { //info tab
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);

            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View view) { //EDIT THE SELECTED NOTE

        int pos = recyclerView.getChildLayoutPosition(view); //getting position of selected note
        Notes n = notesList.get(pos);
        //CODE TO EDIT AN EXISTING NOTE
        existing_note = true;

        Intent intent = new Intent(this, EditActivity.class);

        String title = n.getTitle();
        String text = n.getText();
        Log.d(TAG, "OnClick Title of selected data: " + title);
        intent.putExtra("notesTitle", title); //

        Log.d(TAG, "OnClick Text of selected data: " + text);
        intent.putExtra("notesText", text);

        Log.d(TAG, "onClick position of selected data: " + pos);
        intent.putExtra("position", pos);
        activityResultLauncher.launch(intent);

    }

    @Override
    public boolean onLongClick(View view) {     //DELETE NOTE
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);

        builder.setPositiveButton("OK", (dialog, id) -> { //Delete if yes
            int pos = recyclerView.getChildLayoutPosition(view);
            // Toast.makeText(this, "Delete existing note number " + pos, Toast.LENGTH_SHORT).show();
            notesList.remove(pos);
            nAdapter.notifyItemRemoved(pos);
            saveList();

            if (notesList.size()==0) {
                setTitle("Android Notes ");
            }
            else {
                setTitle("Android Notes " + "(" + String.valueOf(notesList.size()) + ")");
            }
        } );

        builder.setNegativeButton("CANCEL", (dialog, id) -> { } ); //Do nothing if no

        builder.setTitle("Delete note?");

        AlertDialog dialog = builder.create();
        dialog.show();

        return true;
    }

    private void saveList() {   //SAVES LIST TO JSON
        try {
            FileOutputStream fos = getApplicationContext().
                    openFileOutput(("Notes.json"), Context.MODE_PRIVATE);

            PrintWriter printWriter = new PrintWriter(fos);
            printWriter.print(notesList);
            printWriter.close();
            fos.close();

        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    private ArrayList<Notes> loadFile() {
        ArrayList<Notes> notesList = new ArrayList<>();
        try {
            InputStream is = getApplicationContext().openFileInput("Notes.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            JSONArray jsonArray = new JSONArray(sb.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String title = jsonObject.getString("title");
                String text = jsonObject.getString("text");
                String last_save_date = jsonObject.getString("last_save_date");
                Notes notes = new Notes(title, text, last_save_date);
                notesList.add(notes);

//                if (text.length() >=80) {        //if length of chars >= 80, display substring
//                    String subtext = jsonObject.getString("text").substring(0,80);
//                    Notes notes = new Notes(title, subtext, last_save_date);
//                    notesList.add(notes);
//                }
//                else {
//                    String text = jsonObject.getString("text");
//                    Notes notes = new Notes(title, text, last_save_date);
//                    notesList.add(notes);
//                }
            }

        } catch (FileNotFoundException e) {
            Toast.makeText(this, "No file found", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return notesList;
    }

    public void handleResult(ActivityResult result) {

        if (result == null || result.getData() == null) {
            Log.d(TAG, "handleResult: NULL ActivityResult received");
            return;
        }

        //TITLE DATA FROM EDITACTIVITY
        Intent data1 = result.getData();
        String title = data1.getStringExtra("notesTitle");
        Log.d(TAG, "onActivityResult: Saved Title: " + title);

        //TEXT DATA FROM EDITACTIVITY
        Intent data2 = result.getData();
        String text = data2.getStringExtra("notesText");
        Log.d(TAG, "onActivityResult: Saved Text: " + text);

          //DATE DATA FROM EDITACTIVITY
        Intent data3 = result.getData();
        String date = data3.getStringExtra("lastSaveDate");
        Log.d(TAG, "onActivityResult: Saved Text: " + date);

          //POSITION DATA FROM EDITACTIVITY
        Intent data4 = result.getData();
        int pos = data4.getIntExtra("position", 0);

        Notes n = new Notes(title, text, date);
        if (!existing_note) { //if the note is NOT an existing one...
            notesList.add(0,n);

        }

        else { //THE NOTE IS EXISTING THEN REPLACE THE OLD WITH NEW UPDATED ONE

            notesList.set(pos, n);
        }

        saveList();
        notesList.clear();
        notesList.addAll(loadFile());
        nAdapter.notifyDataSetChanged();

        if (notesList.size()==0) {
            setTitle("Android Notes ");
        }
        else {
            setTitle("Android Notes " + "(" + String.valueOf(notesList.size()) + ")");
        }
    }

}