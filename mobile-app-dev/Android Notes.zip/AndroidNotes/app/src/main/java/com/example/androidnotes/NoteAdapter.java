package com.example.androidnotes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<ViewHolder>{

    private ArrayList<Notes> notesList;
    private MainActivity mainAct;

    NoteAdapter(List<Notes> notesList, MainActivity ma) {
        this.notesList = (ArrayList<Notes>) notesList;
        mainAct = ma;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View inflateLayout = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.notes_list_column, parent, false);

        inflateLayout.setOnClickListener(mainAct);
        inflateLayout.setOnLongClickListener(mainAct);


        return new ViewHolder(inflateLayout);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Notes n = notesList.get(position);

        holder.notesTitle.setText(n.getTitle());
        holder.noteText.setText(n.getText());
        holder.date_save.setText(n.getLast_save_date());
        
    }

    @Override
    public int getItemCount() {
        return notesList.size();
    }
}
