package com.example.androidnotes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder {

    TextView notesTitle;
    TextView noteText;
    TextView date_save;

    ViewHolder( View itemView) {
        super(itemView);

        notesTitle = itemView.findViewById(R.id.notesTitle);
        noteText = itemView.findViewById(R.id.notetext);
        date_save = itemView.findViewById(R.id.lastSaveDate);

    }
}
